# fs_gp_yp2425a
This is a mod of the in-game Great Plains YP2425A grain drill for Farming Simulator 19.

Source: https://github.com/dherschberger/fs_gp_yp2425a

This is a simple edit of the in-game Great Plains YP2425A grain drill. The mod references the in-game images and models so this mod is very small.

The edits include adding the ability to directly seed without plowing or cultivating first, and adding fertilization too. Feel free to use this for your own mods
and share however you wish. Leave comments for improvements or issues.

Great Plains Ag is based in Salina, KS. Many thanks to them and Giants for putting this in the game. https://www.greatplainsag.com
